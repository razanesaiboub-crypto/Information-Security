from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


@app.route("/")
def home():
    print("\n========== NEW VISIT ==========")

    print("IP address :", request.remote_addr)
    print("HTTP method :", request.method)
    print("User-Agent :", request.headers.get("User-Agent"))
    print("Accept-Language :", request.headers.get("Accept-Language"))
    print("Accept :", request.headers.get("Accept"))
    print("Accept-Encoding :", request.headers.get("Accept-Encoding"))
    print("Referer :", request.headers.get("Referer"))
    print("Sec-Fetch-Site :", request.headers.get("Sec-Fetch-Site"))
    print("Sec-Fetch-Mode :", request.headers.get("Sec-Fetch-Mode"))
    print("Sec-Fetch-Dest :", request.headers.get("Sec-Fetch-Dest"))
    print("Sec-CH-UA :", request.headers.get("Sec-CH-UA"))
    print("DNT :", request.headers.get("DNT"))

    print("================================\n")
    return render_template("index.html")


@app.route("/collect", methods=["POST"])
def collect():
    data = request.get_json()

    print("\n===== ACTIVE FEATURES RECEIVED =====")
    for key, value in data.items():
        print(f"{key} : {value}")
    print("====================================\n")

    return jsonify({"status": "ok"})


@app.route("/collect_typing", methods=["POST"])
def collect_typing():
    data = request.get_json()

    print("\n===== TYPING BEHAVIOUR RECEIVED =====")
    print("Typing time (s)  :", data.get("typingTime"))
    print("Typing speed     :", data.get("typingSpeed"))
    print("Corrections      :", data.get("corrections"))
    print("=====================================\n")

    return jsonify({"status": "ok"})


@app.route("/collect_fingerprint", methods=["POST"])
def collect_fingerprint():
    data = request.get_json()

    print("\n===== FINGERPRINT HASH RECEIVED =====")
    print("fp :", data.get("fp"))
    print("=====================================\n")

    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True, use_reloader=False)