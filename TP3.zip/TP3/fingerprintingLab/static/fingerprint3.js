async function buildFingerprint() {
  // Features in a fixed order (typing behaviour and windowSize excluded)
  const features = [
    navigator.language,
    navigator.languages.join(","),
    navigator.platform,
    navigator.hardwareConcurrency,
    screen.width + "x" + screen.height,
    screen.colorDepth,
    window.devicePixelRatio,
    Intl.DateTimeFormat().resolvedOptions().timeZone
  ];

  // One string, then bytes
  const combined = features.join(" | ");
  const bytes = new TextEncoder().encode(combined);

  // SHA-256, then conversion to hexadecimal
  const buffer = await crypto.subtle.digest("SHA-256", bytes);
  const hash = Array.from(new Uint8Array(buffer))
    .map(function (b) { return b.toString(16).padStart(2, "0"); })
    .join("");

  document.getElementById("fingerprint-string").textContent = combined;
  document.getElementById("fingerprint-hash").textContent = hash;
  console.log("Fingerprint:", hash);

  // Send only the hash to the server
  fetch("/collect_fingerprint", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fp: hash })
  })
    .then(function (response) { return response.json(); })
    .then(function (result) { console.log("Server answer:", result); })
    .catch(function (error) { console.error("Send error:", error); });
}

buildFingerprint();