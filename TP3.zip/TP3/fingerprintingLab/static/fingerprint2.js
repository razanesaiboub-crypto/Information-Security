// Éléments de la page
const targetSentence = document.getElementById("target-sentence").textContent.trim();
const typingInput = document.getElementById("typing-input");
const restartButton = document.getElementById("restart-button");
const typingTimeOutput = document.getElementById("typing-time");
const typingSpeedOutput = document.getElementById("typing-speed");
const typingCorrectionsOutput = document.getElementById("typing-corrections");

// État de l'expérience
let startTime = null;
let corrections = 0;
let finished = false;

// Premier caractère = départ du chrono ; Backspace = correction
typingInput.addEventListener("keydown", function (event) {
  if (finished) return;

  if (startTime === null && event.key.length === 1) {
    startTime = performance.now();
  }

  if (startTime !== null && event.key === "Backspace") {
    corrections++;
  }
});

// Vérifier si la phrase est reproduite exactement
typingInput.addEventListener("input", function () {
  if (finished || startTime === null) return;

  if (typingInput.value === targetSentence) {
    finished = true;
    const totalTime = (performance.now() - startTime) / 1000;
    const speed = targetSentence.length / totalTime;

    typingTimeOutput.textContent = totalTime.toFixed(2) + " s";
    typingSpeedOutput.textContent = speed.toFixed(2) + " chars/s";
    typingCorrectionsOutput.textContent = corrections;

    // Envoi des résultats au serveur Flask
    const typingData = {
      typingTime: totalTime.toFixed(2),
      typingSpeed: speed.toFixed(2),
      corrections: corrections
    };

    console.log("Typing results:", typingData);

    fetch("/collect_typing", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(typingData)
    })
      .then(function (response) { return response.json(); })
      .then(function (result) { console.log("Server answer:", result); })
      .catch(function (error) { console.error("Send error:", error); });
  }
});

// Recommencer l'expérience
restartButton.addEventListener("click", function () {
  startTime = null;
  corrections = 0;
  finished = false;
  typingInput.value = "";
  typingTimeOutput.textContent = "";
  typingSpeedOutput.textContent = "";
  typingCorrectionsOutput.textContent = "";
  typingInput.focus();
});