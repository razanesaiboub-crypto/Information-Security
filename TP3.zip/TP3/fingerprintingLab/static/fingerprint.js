const features = {
  // navigator
  language: navigator.language,
  languages: navigator.languages.join(","),
  platform: navigator.platform,
  hardwareConcurrency: navigator.hardwareConcurrency,

  // screen
  screenSize: screen.width + "x" + screen.height,
  colorDepth: screen.colorDepth,

  // window
  windowSize: window.innerWidth + "x" + window.innerHeight,
  devicePixelRatio: window.devicePixelRatio,

  // Intl
  timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
};

// Show in the console
console.log("Active features:", features);

// Show on the page
const outputElement = document.getElementById("feature-output");
let text = "";
for (const [key, value] of Object.entries(features)) {
  text += key + ": " + value + "\n";
}
outputElement.style.whiteSpace = "pre-line";
outputElement.textContent = text;
// Send the features to the Flask server
fetch("/collect", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(features),
})
  .then((response) => response.json())
  .then((data) => console.log("Server answered:", data));