# Usage: python3 investigate.py file.enc output.png
import sys
from collections import Counter
from PIL import Image

W, H = 432, 475
data = open(sys.argv[1], "rb").read()[16:]       # skip "Salted__" (8) + salt (8)
blocks = [data[i:i+16] for i in range(0, len(data), 16)]
blocks = blocks[:W * H // 16]                     # drop the padding block

count = Counter(blocks)
ids = {b: i for i, b in enumerate(count)}         # same block -> same id
repeated = sum(c for c in count.values() if c > 1)
print("blocks:", len(blocks), "| distinct:", len(count), "| in repeated groups:", repeated)

# one block = 16 pixels; give all 16 pixels the block's grey value
pixels = []
for b in blocks:
    pixels += [(ids[b] * 37) % 256] * 16
img = Image.new("L", (W, H))
img.putdata(pixels)
img.save(sys.argv[2])
