from PIL import Image
Image.frombytes("L", (432, 475), open("recovered.raw", "rb").read()).save("recovered.png")
