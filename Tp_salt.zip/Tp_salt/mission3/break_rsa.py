# Usage: python3 break_rsa.py n e
import sys, math
n, e = int(sys.argv[1]), int(sys.argv[2])

p = next(i for i in range(2, math.isqrt(n) + 1) if n % i == 0)   # trial division
q = n // p
d = pow(e, -1, (p - 1) * (q - 1))
print("p =", p, "\nq =", q, "\nd =", d)
