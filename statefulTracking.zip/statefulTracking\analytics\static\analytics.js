(function () {
  function getCookie(name) {
    const m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return m ? m[1] : null;
  }

  // 1. Vérifier si le cookie analytics existe
  let aid = getCookie("aid_analytics");

  // 2-4. Sinon, générer un id aléatoire et le stocker (1 an)
  if (!aid) {
    const bytes = new Uint8Array(8);
    crypto.getRandomValues(bytes);
    aid = Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
    document.cookie = "aid_analytics=" + aid + "; max-age=31536000; path=/";
  }

  // 5. Envoyer l'activité à l'analytics (balise image, pas de CORS à gérer)
  const params = new URLSearchParams({
    aid: aid,
    site: location.hostname,
    page: location.pathname,
    title: document.title
  });
  new Image().src = "http://analytics.test:9100/collect?" + params.toString();
})();