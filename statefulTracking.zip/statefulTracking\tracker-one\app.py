from flask import Flask, request, make_response, render_template
from collections import defaultdict
from datetime import datetime
import secrets

app = Flask(__name__)
tracking_log = []

@app.route("/track")
def track():
    tid = request.cookies.get("tid")
    is_new = tid is None
    if is_new:
        tid = secrets.token_hex(8)

    publisher = request.args.get("publisher", "unknown")
    page = request.args.get("page", "unknown")

    tracking_log.append({
        "id": tid,
        "publisher": publisher,
        "page": page,
        "time": datetime.now().strftime("%H:%M:%S"),
    })

    print(f"\n[TRACKER] id={tid} | publisher={publisher} | page={page} | new={is_new}")
    print(f"  Cookie header reçu : {request.headers.get('Cookie')}")
    for e in tracking_log:
        if e["id"] == tid:
            print(f"  [{e['time']}] {e['publisher']} -> {e['page']}")

    response = make_response(render_template("tracker.html", tid=tid))
    response.headers["Cache-Control"] = "no-store"
    if is_new:
        # Cookie persistant (1 an), sans SameSite/Secure pour fonctionner en HTTP
        response.set_cookie(key="tid", value=tid, max_age=60 * 60 * 24 * 365, path="/")
    return response

@app.route("/profiles")
def profiles():
    out = defaultdict(list)
    for e in tracking_log:
        out[e["id"]].append(f'{e["time"]}  {e["publisher"]}  {e["page"]}')
    if not out:
        return "<pre>Aucune donnée</pre>"
    return "<pre>" + "\n\n".join(
        f"ID {tid}\n  " + "\n  ".join(lines) for tid, lines in out.items()
    ) + "</pre>"

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=9000, debug=True)