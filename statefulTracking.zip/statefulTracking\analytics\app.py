from flask import Flask, request
from collections import defaultdict
from datetime import datetime

app = Flask(__name__)
events = []

@app.before_request
def log_every_request():
    # Sert à répondre à la question : reçoit-on les cookies des publishers ?
    print(f"\n[REQUEST] {request.method} {request.path}")
    print(f"  Referer       : {request.headers.get('Referer')}")
    print(f"  Cookie header : {request.headers.get('Cookie')}")

@app.route("/collect")
def collect():
    e = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "aid": request.args.get("aid"),
        "site": request.args.get("site"),
        "page": request.args.get("page"),
        "title": request.args.get("title"),
    }
    events.append(e)
    print(f"  [ANALYTICS] aid={e['aid']} | {e['site']}{e['page']}")
    return ("", 204)

@app.route("/profiles")
def profiles():
    out = defaultdict(list)
    for e in events:
        out[e["aid"]].append(f"{e['time']}  {e['site']}{e['page']}  ({e['title']})")
    if not out:
        return "<pre>Aucune donnée</pre>"
    return "<pre>" + "\n\n".join(
        f"AID {aid}\n  " + "\n  ".join(lines) for aid, lines in out.items()
    ) + "</pre>"

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=9100, debug=True)