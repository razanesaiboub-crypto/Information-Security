
import time
from collections import deque
from urllib.parse import (
    urljoin, urldefrag, urlsplit, urlunsplit
)

import requests
from bs4 import BeautifulSoup

START_URL = "https://books.toscrape.com/"
ALLOWED_HOST = "books.toscrape.com"
MAX_PAGES = 10
DELAY = 2
TIMEOUT = 10

queue = deque([START_URL])
discovered = {START_URL}
visited = set()
edges = []

session = requests.Session()
session.headers.update({
    "User-Agent": "CampusShieldStudentCrawler/1.0"
})


def normalize_url(link, base_url):
    # Convert relative URLs to absolute URLs.
    absolute = urljoin(base_url, link)

    # Remove URL fragments, such as #reviews.
    absolute, _ = urldefrag(absolute)

    parts = urlsplit(absolute)

    # Follow only HTTP/HTTPS URLs on the allowed host.
    if parts.scheme not in ("http", "https"):
        return None

    if parts.hostname != ALLOWED_HOST:
        return None

    # Ignore non-HTML resources by their extension.
    ignored = (
        ".jpg", ".jpeg", ".png", ".gif", ".svg",
        ".css", ".js", ".pdf", ".zip", ".ico"
    )

    if parts.path.lower().endswith(ignored):
        return None

    # Normalize the hostname and remove the default port.
    port = parts.port
    if port not in (None, 80, 443):
        return None

    normalized = urlunsplit((
        parts.scheme,
        ALLOWED_HOST,
        parts.path or "/",
        parts.query,
        ""
    ))

    return normalized


last_request_time = None

while queue and len(visited) < MAX_PAGES:
    url = queue.popleft()

    if url in visited:
        continue

    # Ensure at least 2 seconds between HTTP requests.
    if last_request_time is not None:
        elapsed = time.monotonic() - last_request_time
        if elapsed < DELAY:
            time.sleep(DELAY - elapsed)

    print(f"\nVisiting: {url}")

    # Count attempts before sending, even on failure.
    visited.add(url)
    last_request_time = time.monotonic()

    try:
        response = session.get(
            url,
            timeout=TIMEOUT,
            allow_redirects=False
        )

        print("Status:", response.status_code)

        content_type = response.headers.get(
            "Content-Type", ""
        ).lower()

        if response.status_code != 200:
            print("Skipping non-200 response")
            continue

        if "text/html" not in content_type:
            print("Skipping non-HTML response")
            continue

        soup = BeautifulSoup(
            response.content, "html.parser"
        )

        for tag in soup.find_all("a", href=True):
            new_url = normalize_url(
                tag["href"], url
            )

            if new_url is None:
                continue

            edges.append((url, new_url))

            if new_url not in discovered:
                discovered.add(new_url)
                queue.append(new_url)

    except requests.RequestException as error:
        print("Request failed:", error)

print("\n===== CRAWLER SUMMARY =====")
print("Pages attempted:", len(visited))
print("Unique URLs discovered:", len(discovered))
print("Links recorded:", len(edges))

print("\nVisited URLs:")
for page in sorted(visited):
    print(page)

with open("crawler_results.txt", "w", encoding="utf-8") as file:
    file.write("Visited URLs:\n")
    for page in sorted(visited):
        file.write(page + "\n")

    file.write("\nDiscovered links:\n")
    for source, destination in edges:
        file.write(f"{source} -> {destination}\n")

print("\nResults saved to crawler_results.txt")
